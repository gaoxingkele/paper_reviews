# 风险分析报告 — P1：Knowledge-Enhanced NSGA-II for Multi-Objective Economic Emission Dispatch

> 由多 Agent 论文评审模拟器生成（示范）。论文当前模板：IEEE Access。
> 评估期刊：IEEE Access · MDPI Energies · MDPI Electronics · MDPI Applied Sciences

---

## 0. 论文画像

- **核心方法**：KE-NSGA-II = 启发式（merit-order）初始化 + 领域知识可行性 repair，用于 IEEE 30-bus 6-unit 经济排放调度（EED）。
- **核心结论（关键张力点）**：消融实验显示 **repair-only 配置反而显著优于完整 KE-NSGA-II**（hypervolume p = 7.32×10⁻⁷），论文据此把叙事从"知识越多越好"重构为"repair 主导、额外初始化偏置反而有害"。
- **结论类型**：诚实的**消融反转 / 自我削弱**型——这是本系统重点处理的高期刊敏感度场景。

---

## 1. 三 Agent 发现摘要

### Agent A — 严格审稿人（创新/贡献 D1·D2）

| severity | issue | reviewer_voice（模拟原话） | 期刊敏感度 |
|---|---|---|---|
| 2 | 创新点是"机制选择"叙事而非新算法 | "The two mechanisms (merit-order init + feasibility repair) are both standard dispatch heuristics. The contribution is the ablation insight, not a new operator." | IEEE Access 低（distinct 即可）；MDPI 中（Novelty 维度承压） |
| 3 (MDPI) / 1 (Access) | 消融反转削弱"完整方法"卖点 | "If repair-only beats the full method, the title 'Knowledge-Enhanced' overstates the proposed system. The real finding is narrower than the framing." | MDPI 高（Novelty/Merit）；Access 低（结论诚实且 distinct） |
| 1 | 价值叙事尚可但可更强 | "The reframing toward mechanism selection is interesting, but the 'why this matters beyond this benchmark' argument is thin." | MDPI Interest 维度敏感 |

### Agent B — 格式/规范检查员（D6·D7）

| severity | issue | reviewer_voice | 期刊敏感度 |
|---|---|---|---|
| 2 | **DOI/日期占位符残留** "10.1109/ACCESS.2026.XXXXXXX"、"date of publication June 00, 2026" | "Placeholder DOI and publication date remain — must be the journal template defaults, clean before submission." | 两刊均需修，提交版必清 |
| 2 | 页脚 "VOLUME 11, 2023" 与正文 2026 年不一致 | "Running footer says VOLUME 11, 2023 while the paper is dated 2026 — template footer not updated." | 低敏感但显粗糙 |
| 1 | 章节标题异常："I. REPAIR-DOMINANT KE-NSGA-II FOR ECONOMIC-ENVIRONMENTAL DISPATCH" 下又套 "A. INTRODUCTION" | "Top-level section heading reads like a result statement rather than a section title; structure is unusual." | Access 中（结构）；MDPI 需符合 section 模板 |
| 1 | 引用新近度/自引未知，需核 | "Ensure recent (≤5yr) references dominate and self-citation is limited." | MDPI 高（5yr/自引规则） |

### Agent C — 方法论质疑者（D3·D4·D5）

| severity | issue | reviewer_voice | 期刊敏感度 |
|---|---|---|---|
| 1 | 统计严谨性强（30 runs + Wilcoxon + Holm-Bonferroni + Cliff's δ） | "Statistical protocol is commendable — 30 runs, rank-sum with Holm correction and effect sizes. Few EED papers do this." | 两刊均加分 |
| **3** | **单 benchmark 泛化性**：结论仅基于 IEEE 30-bus 6-unit | "The central claim (init bias is harmful when combined with repair) rests on ONE benchmark. Is this a property of EED, or of this 6-unit system at 700 MW? Needs ≥2 systems." | 两刊均严重；Access 关注过度声明，MDPI 关注 Interest/泛化 |
| 2 | 消融反转的机制解释偏描述性 | "You observe a sub-additive interaction but the causal explanation (why init bias hurts repair) is hand-wavy. Diversity loss? Provide diagnostic evidence." | 两刊中等 |
| 2 | demand-sensitivity 仅 700 MW 主场景 | "Sensitivity study exists but the headline numbers are all at 700 MW. Robustness across demand levels under-reported." | MDPI Energies 高（能源工况价值） |
| 1 | 基线公平性较好（统一 penalty + 相同算子配置） | "Baselines share the unified penalty framework and SBX/PM config — fair comparison." | 两刊加分 |

---

## 2. 维度聚合分（0–4）

| 维度 | D1 创新 | D2 价值 | D3 技术 | D4 基线 | D5 复现 | D6 格式 | D7 引用英语 |
|---|---|---|---|---|---|---|---|
| DimScore | 2.6 | 2.4 | 3.0 | 1.5 | 2.0 | 2.0 | 1.5 |

---

## 3. 风险分析矩阵（期刊 × 维度加权贡献）

| 维度（权重见各列） | IEEE Access | MDPI Energies | MDPI Electronics | MDPI Applied Sci |
|---|---|---|---|---|
| D1 创新 | 0.26 | 0.47 | 0.47 | 0.42 |
| D2 价值 | 0.29 | 0.43 | 0.38 | 0.43 |
| D3 技术 soundness | **0.72** | 0.54 | 0.54 | 0.54 |
| D4 基线公平 | 0.27 | 0.18 | 0.21 | 0.21 |
| D5 复现 | 0.32 | 0.24 | 0.24 | 0.24 |
| D6 格式 | 0.16 | 0.24 | 0.24 | 0.24 |
| D7 引用/英语 | 0.18 | 0.15 | 0.15 | 0.15 |
| **RawRisk (0–4)** | 2.20 | 2.25 | 2.23 | 2.23 |
| **RRI (0–100)** | **55** | **56** | **56** | **56** |
| **风险标签** | 偏高风险 | 偏高风险 | 偏高风险 | 偏高风险 |
| **预测决策** | **Reject（边缘，无大修缓冲）** | **Major Revision** | **Major Revision** | **Major Revision** |
| 一票否决 | 未触发 | — | — | — |

> **关键洞察**：四刊 RRI 接近，但**风险后果截然不同**。IEEE Access 的二元模型让"偏高风险"直接等于拒稿；MDPI 的"偏高风险"是 Major Revision——同一篇论文在 MDPI 有挽救机会。**最致命的单一维度是 D3（单 benchmark 泛化性），在所有期刊都是头号阻塞项。**

---

## 4. 改进策略（按 Priority 降序）

| # | 改进动作 | 解决维度 | 收益最大期刊 | fixability | 期刊冲突 |
|---|---|---|---|---|---|
| 1 | **增补至少 1–2 个额外 benchmark**（如 IEEE 118-bus 或不同机组规模），验证"init bias 有害"是否泛化 | D2,D3 | 全部 | 0.3（需补实验） | 无；IEEE Access 注意篇幅 |
| 2 | **为消融反转提供因果诊断证据**（如初始化导致的多样性损失曲线），把"描述"升级为"解释" | D3 | 全部 | 0.5 | 无 |
| 3 | **校准标题与贡献声明**：让标题/摘要如实反映"repair 主导"的核心发现，避免"Knowledge-Enhanced"过度承诺 | D1,D2 | MDPI 三刊 | 0.9 | 无（IEEE Access 也受益于"不过度声明"） |
| 4 | **清理模板占位符**（DOI、日期、VOLUME 页脚、异常章节标题） | D6 | 全部 | 1.0 | 无 |
| 5 | **强化 demand-sensitivity 报告**，给出多工况下的稳定性 | D2,D3 | MDPI Energies | 0.5 | 无 |
| 6 | **核对引用新近度与自引比例**（MDPI 规则） | D7 | MDPI 三刊 | 0.9 | 无 |

---

## 5. 投稿建议

- **首选：MDPI Energies 或 Applied Sciences**。理由：① 该论文统计严谨、结论诚实，契合 MDPI 的 DORA 立场（接受有价值的负面/反直觉结论）；② MDPI 的 Major Revision 缓冲允许通过补 benchmark 把头号风险 D3 降下来，而 IEEE Access 二元模型下"偏高风险"几乎等于直接拒；③ Energies 对 EED 这类能源系统优化的读者价值（D2）天然友好。
- **若坚持 IEEE Access**：必须在投稿前先解决 **#1（多 benchmark 泛化）+ #3（标题/声明校准）+ #4（模板清理）**，否则在 Scope & Quality Check 或首轮二元评审中大概率被拒，且无修改机会。
- **Electronics** 适配略弱（其 scope 偏电子/通信而非电力调度），优先级低于 Energies。
