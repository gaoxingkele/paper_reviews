# 风险分析报告 — P2：Investigating the Value of LODF-Based Physics Priors for ML-Driven N-1 Contingency Screening

> 由多 Agent 论文评审模拟器生成（示范）。论文当前模板：IEEE Access。
> 评估期刊：IEEE Access · MDPI Energies · MDPI Electronics · MDPI Applied Sciences

---

## 0. 论文画像

- **核心方法**：系统对比 8 种条件（LODF 线性筛查、raw-feature RF/HGB、physics-residual、physics-concat）在 IEEE 39-bus 上做 N-1 contingency screening，辅以 14-bus/118-bus。
- **核心结论（关键张力点）**：**physics prior（LODF）对强 tabular 模型（HGB）无显著增益**——raw-feature HGB 的 F1=0.982 边际但显著优于 physics-residual（F1=0.980, p=0.020, Holm p=0.039）；residual 架构相比 naive concat 也无优势（p=0.432）。
- **结论类型**：典型**负面结果（negative result）**——本系统最高期刊敏感度场景。

---

## 1. 三 Agent 发现摘要

### Agent A — 严格审稿人（创新/贡献 D1·D2）

| severity | issue | reviewer_voice（模拟原话） | 期刊敏感度 |
|---|---|---|---|
| 3 (MDPI) / 1 (Access) | 贡献是"否定一个流行假设"而非提出新方法 | "The paper's contribution is a negative finding: physics-informed integration doesn't help here. Valuable, but reviewers will ask whether this is a publishable advance or just a null result on one system." | MDPI 高（Novelty）；Access 低（distinct + 技术正确即可） |
| 2 | 价值叙事依赖"边界条件"论证，需更锋利 | "The framing 'physics helps only when the base model is weak' is the real contribution — make it the headline, not a footnote in the abstract." | MDPI Interest/Merit 高敏感 |
| 0 | 问题设定清晰、动机充分 | "The research question is crisp and well-motivated — does explicit physics add info beyond raw features?" | 两刊加分 |

### Agent B — 格式/规范检查员（D6·D7）

| severity | issue | reviewer_voice | 期刊敏感度 |
|---|---|---|---|
| 2 | DOI/日期占位符残留 "ACCESS.2025.xxxxxxx"、"xxxx 00, 0000" | "Template placeholders for DOI and dates not filled." | 两刊均需修 |
| 1 | 页脚 "VOLUME 11, 2023" 与 2025 年不符 | "Footer volume/year mismatch." | 低 |
| 1 | 引用新近度/自引待核 | "Verify ≤5yr reference share and self-citation for MDPI." | MDPI 高 |
| 0 | 条件 C1–C8 定义清晰、结构规范 | "The eight-condition design is cleanly enumerated — good structure." | 加分 |

### Agent C — 方法论质疑者（D3·D4·D5）

| severity | issue | reviewer_voice | 期刊敏感度 |
|---|---|---|---|
| 0 | **方法论非常扎实**：10-fold grouped CV + Wilcoxon signed-rank + Holm + Cliff's δ + 35,000 样本 + 类不平衡三重处理 | "This is a rigorously designed study — grouped CV prevents leakage, paired tests with effect sizes, principled imbalance handling. Exemplary." | 两刊强加分 |
| **3** | **负面结果的泛化边界**：核心结论基于 IEEE 39-bus；14/118-bus 被作者自承"反映 benchmark 构造敏感性而非可泛化物理" | "If the supplementary systems show performance varies with benchmark construction rather than physics, can the headline null result be generalized at all? This actually weakens external validity." | 两刊均严重；MDPI Interest 维度尤甚 |
| 2 | **伪负面风险**：physics 无增益是否因为只用了 classical LODF（作者已承认 AC-consistent/voltage-aware 线性化可能携带非冗余信息） | "You concede that AC-consistent linearizations might carry non-redundant info. Then the null result may be specific to classical LODF, not physics priors in general — the title over-generalizes." | 两刊中高；IEEE Access 关注过度声明 |
| 2 | 边际显著（p=0.020）被作为 raw>physics 的依据，效应量 Cliff's δ=−0.580 方向需谨慎解读 | "F1 0.982 vs 0.980 is a 0.002 gap. Even if statistically significant, is it practically meaningful? Avoid over-interpreting a marginal difference." | 两刊中等 |
| 1 | LODF 无效条目处理（NaN/inf）讨论充分，是亮点 | "The treatment of invalid LODF entries is a genuine practical contribution often ignored elsewhere." | 加分 |

---

## 2. 维度聚合分（0–4）

| 维度 | D1 创新 | D2 价值 | D3 技术 | D4 基线 | D5 复现 | D6 格式 | D7 引用英语 |
|---|---|---|---|---|---|---|---|
| DimScore | 2.6 | 2.4 | 3.0 | 1.0 | 1.0 | 2.0 | 1.3 |

---

## 3. 风险分析矩阵（期刊 × 维度加权贡献）

| 维度 | IEEE Access | MDPI Energies | MDPI Electronics | MDPI Applied Sci |
|---|---|---|---|---|
| D1 创新 | 0.26 | 0.47 | 0.47 | 0.42 |
| D2 价值 | 0.29 | 0.43 | 0.38 | 0.43 |
| D3 技术 soundness | **0.72** | 0.54 | 0.54 | 0.54 |
| D4 基线公平 | 0.18 | 0.12 | 0.14 | 0.14 |
| D5 复现 | 0.16 | 0.12 | 0.12 | 0.12 |
| D6 格式 | 0.16 | 0.24 | 0.24 | 0.24 |
| D7 引用/英语 | 0.16 | 0.13 | 0.13 | 0.13 |
| **RawRisk (0–4)** | 1.93 | 2.05 | 2.02 | 2.02 |
| **RRI (0–100)** | **48** | **51** | **51** | **51** |
| **风险标签** | 中风险 | 偏高风险 | 偏高风险 | 偏高风险 |
| **预测决策** | **边缘 Accept/Reject（偏接受）** | **Major Revision** | **Major Revision** | **Major Revision** |
| 一票否决 | 未触发 | — | — | — |

> **关键洞察**：这是三篇中**最适合 IEEE Access 的论文**。其方法论极扎实（D3 接近满分加分），而 IEEE Access "技术正确 + distinct 即可、不要求高创新"的哲学，对"扎实的负面结果"异常友好——negative result 在这里不是减分项。反观 MDPI，虽然 DORA 接受负面结果，但 Novelty/Interest 是显式计分维度，会把 RRI 推到偏高，导向 Major Revision。**头号阻塞项是 D3/D2 中的"负面结论过度泛化"风险**。

---

## 4. 改进策略（按 Priority 降序）

| # | 改进动作 | 解决维度 | 收益最大期刊 | fixability | 期刊冲突 |
|---|---|---|---|---|---|
| 1 | **收窄结论范围**：把标题/摘要从"physics priors 无价值"改为"classical LODF 对强 tabular 模型无增益"，明确边界条件 | D2,D3 | 全部 | 0.95 | 无 |
| 2 | **强化"边界条件"作为正向贡献**：把"physics 仅在 base model 弱/捕获非冗余信息时有用"提升为核心卖点 | D1,D2 | MDPI 三刊 | 0.8 | 无 |
| 3 | **补充弱基线实验佐证边界论断**：用一个故意削弱的 base model 展示 physics 此时确有增益，把推测变成证据 | D2,D3 | 全部 | 0.4 | 无 |
| 4 | **谨慎化边际显著的措辞**：F1 0.982 vs 0.980 同时报告实际意义而非仅统计显著 | D3 | 全部 | 0.95 | 无 |
| 5 | 清理模板占位符与页脚 | D6 | 全部 | 1.0 | 无 |
| 6 | 核对引用新近度/自引（MDPI） | D7 | MDPI 三刊 | 0.9 | 无 |

---

## 5. 投稿建议

- **首选：IEEE Access**。理由：① 论文方法论质量是其最强资产，而 IEEE Access 的评判核心正是"技术是否 sound、是否 distinct"，对扎实的负面结果天然友好；② IEEE Access 官方明确"不要求高创新度"，恰好避开本文最大短板（Novelty）；③ 只要在投稿前完成 #1（收窄结论）+ #4（措辞谨慎）+ #5（模板清理），即可显著降低唯一的实质风险——过度泛化。
- **次选：MDPI Energies**（电网 N-1 安全契合能源系统 scope）。需先完成 #2（把边界条件包装成正向贡献）以抬高 Interest/Merit，否则 Major Revision 中审稿人会反复追问"这个负面结果的价值"。
- **Electronics/Applied Sciences**：可投但读者契合度低于 Energies。
