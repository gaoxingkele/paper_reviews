# 多 Agent 论文评审模拟器

面向 **IEEE Access** 与 **MDPI（Energies / Electronics / Applied Sciences）** 的差异化审稿仿真系统。
适用领域：计算机 × 电力系统交叉。交付形态：**设计文档 + 提示词框架（可接入任意 LLM）**。

## 这是什么

三个角色互补的 Agent 对论文做多视角拆解，并映射到不同期刊的**真实官方审稿逻辑**，量化录用风险、输出风险矩阵与改进策略。核心价值在于揭示：对"诚实的负面/非-SOTA 结论"型论文，**期刊选择本身就是最大的风险杠杆**。

| Agent | 角色 | 关注 |
|---|---|---|
| A | 严格审稿人 | 创新点与贡献（D1/D2） |
| B | 格式/规范检查员 | LaTeX 格式与引用规范（D6/D7） |
| C | 方法论质疑者 | 模拟特定期刊审稿逻辑（D3/D4/D5） |

## 怎么用

1. 读 `01_design/00_系统设计文档.md` 了解全貌。
2. 把论文正文注入 `02_prompts/` 的三个 Agent 提示词（替换 `{{PAPER_TEXT}}`、`{{TARGET_JOURNAL}}`，并贴入 `03_journal_kb/` 对应期刊知识库）。
3. 三个 Agent 各输出符合 `04_schemas/agent_finding.schema.json` 的 JSON。
4. 用 `02_prompts/aggregator_聚合器.md` 聚合，得到符合 `04_schemas/risk_matrix.schema.json` 的风险矩阵 + 改进报告。
5. 对 4 个期刊各跑一次，汇成跨期刊对比总表。

## 目录

```
01_design/    系统设计文档 + 风险评分方法论
02_prompts/   三个 Agent + 聚合器的提示词
03_journal_kb/ IEEE Access / MDPI 三刊 官方审稿逻辑知识库
04_schemas/   Agent 发现 / 风险矩阵 的 JSON Schema
05_reports/   针对你上传的 3 篇论文的示范风险报告 + 跨期刊对比总表
```

## 立即可看的成果

`05_reports/跨期刊风险对比总表.md` —— 已对你上传的 P1(KE-NSGA-II)、P2(LODF)、P3(KGRAT) 三篇论文跑出完整风险评估与投稿建议。

> 本系统全部依据官方一手审稿标准建模（IEEE Access Reviewer Guidelines、MDPI Reviewer Brochure / Review Report Form 等，引用见知识库文件）。输出为审稿风险仿真，供投稿前自检与期刊选择参考。
