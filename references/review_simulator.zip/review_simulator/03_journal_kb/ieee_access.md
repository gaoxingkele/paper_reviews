# 期刊知识库：IEEE Access

> 供 Agent 注入的事实片段。全部来自官方一手来源。

## 决策模型
- **二元 accept/reject**，无 minor/major revision 安全网。最低 2 名独立审稿人，单盲。
- 三阶段预筛：① 抄袭/相似度扫描 ② Scope & Quality Check（不达标 desk reject，无详细反馈）③ AE 二次把关。来源：[Stages of Peer Review](https://ieeeaccess.ieee.org/authors/stages-of-peer-review/)

## 审稿哲学（最关键）
- 官方原文："IEEE Access 文章**不必有高水平创新（not necessarily expected to have a high level of novelty）**，但必须**区别于既往发表（distinct from previous publications）且技术 sound**。"来源：[Reviewer Guidelines](https://ieeeaccess.ieee.org/reviewers/reviewer-guidelines/)
- 评判核心问题："这篇论文是否做出了**正确执行（correctly executed）且完整描述**的真实技术贡献？"——不是"这是否是年度最重要论文"。

## 录用 7 条硬标准
来源：[Preparing Your Article](https://ieeeaccess.ieee.org/authors/preparing-your-article/)
1. 原创写作，增进既有知识体系（综述/survey 亦可，但须有明确推进）。
2. 结果未一稿多投/未在他处发表（会议扩展版与 preprint 可，须披露）。
3. 实验/统计/分析达到**高技术标准**且描述充分。
4. 结论清晰且由数据支撑。
5. **标准英语 + 正确语法**。
6. 包含恰当的相关既往工作引用。
7. 落在 IEEE Access scope 内。

## 红线（触发立即拒/退回）
- **语法差 → 立即拒（immediately rejected）**。来源：[Submission Guidelines](https://ieeeaccess.ieee.org/authors/submission-guidelines/)
- 抄袭（含自我抄袭）→ 拒 + 上报 IEEE Publishing Ethics。
- **撤稿文献**：影响有效性则退回删除或拒稿。
- ML/DL 论文：必须与相关 SOTA 基线在标准 benchmark 上公平对比。

## 格式硬约束
- 双栏单倍行距，必须用 IEEE Access 官方模板；Word/LaTeX + PDF 双文件，内容须完全一致，单文件 ≤ 40MB。
- 摘要 150–250 词、单段、无缩写/公式/引用。
- 关键词 3–10 个；首字母缩写首次出现须定义（即使摘要已定义）。
- 强烈建议正文 < 20 页（含图表）；超 20 页需 EIC 预审批准。
- 强烈鼓励/日益要求公开代码（算法/AI 类）。

## Agent 调参提示
- **Agent A（创新）**：降低创新度严格度——"distinct 即可"，不要因"非-SOTA / 增量"扣高分；但"与既往无可辨识差异"是致命。
- **Agent B（格式）**：把英语语法、模板合规、撤稿文献设为高敏感；引用新近度相对宽松。
- **Agent C（方法论）**：把技术 soundness、基线公平、复现性设为最高优先；任一致命缺陷触发一票否决（二元模型无大修缓冲）。
