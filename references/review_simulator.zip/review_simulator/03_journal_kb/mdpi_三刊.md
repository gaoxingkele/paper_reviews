# 期刊知识库：MDPI（Energies / Electronics / Applied Sciences）

> 供 Agent 注入的事实片段。全部来自官方一手来源。

## 决策模型
- **结构化 6 维评分 + 4 档建议**。
- 4 档：Accept / **Minor Revision / Major Revision** / Reject。Reject 定义："文章有严重缺陷且无原创贡献，拒稿且不提供本刊再投机会"。来源：[MDPI Review Report Form](https://mdpi-res.com/data/review-report-form.docx)
- 流程：编辑部检查（抄袭/AI/ethics/data）→ 学术编辑预检（scope + 显著性）→ 同行评审 → 决定。首轮决定通常约 2 周（Electronics 等快刊）。

## 6 个评分维度（High / Average / Low / No Answer）
来源：[MDPI Reviewer Guidelines](http://www.989892.me/reviewers.html) · [Reviewer Brochure](https://mdpi-res.com/data/mdpi-reviewer-brochure-2022.pdf)
1. **Novelty**：问题是否原创且明确定义？结果是否推进现有知识？
2. **Scope**：是否契合期刊 scope？
3. **Significance**：结果解读是否恰当且显著？结论是否被结果支撑？假设是否清晰标注？
4. **Quality (of Presentation)**：写作/数据/图表呈现是否达最高标准？
5. **Scientific Soundness**：设计是否正确、技术是否 sound、数据是否足以支撑结论、方法是否足以复现、原始数据是否可得？
6. **Interest to the Readers**：结论是否吸引广泛读者？
+ **Overall Merit**：发表是否有整体收益？**是否呈现了一个有效科学假设的负面结果（present a negative result of a valid scientific hypothesis）？**
+ **English Level**：语言是否恰当可懂？

## 关键哲学（与 IEEE Access 的核心差异）
- MDPI 是 **DORA 签署方**。官方原文："我们旨在发表**所有科学正确的稿件**，让广大读者群体定义影响力……我们**同时发表正面与负面结果，不人为抬高拒稿率**。"来源：[Reviewer Brochure](https://mdpi-res.com/data/mdpi-reviewer-brochure-2022.pdf)
- 含义：**负面/非-SOTA 结论本身不是减分项**，反而 Overall Merit 维度显式询问"是否呈现有效假设的负面结果"。但 **Interest/Significance/Merit** 维度会追问"这个负面结论是否足够有趣、值得读者关注"。

## 引用规范（高频大修触发点）
- 引用应**以近 5 年为主、相关**。
- **不得过度自引（excessive self-citation）**。
- 引用须切实支撑论述。

## 其他考核项
- ethics statement、**data availability statement** 是否充分。
- 结果是否可基于 methods 复现。
- 图表是否恰当、易读、解释一致。
- 结论是否承认 limitations。

## 三刊微差（scope 侧重）
- **Energies**：能源系统/电力/可再生/能效价值导向，D2（价值/能源意义）权重略高。
- **Electronics**：电气/电子/通信工程，方法新颖与电子系统实现，D1（创新）略高；欢迎"rudimentary and challenging studies"。来源：[Applied Sciences EEC section flyer](https://mdpi-res.com/data/9.-section-flyer-for-electrical-electronics-and-communications-engineering_print.pdf)
- **Applied Sciences**：跨学科应用广度，D2（应用价值/读者面）略高。

## Agent 调参提示
- **Agent A（创新）**：创新度严格度中等——Novelty 是显式计分维度，"增量/非-SOTA"会压低 Novelty；但负面结论可由 Overall Merit 部分补偿，前提是价值叙事到位。
- **Agent B（格式）**：把**近 5 年引用比例、自引比例、data availability statement、MDPI 模板/section 结构**设为高敏感；英语为大修而非直接拒。
- **Agent C（方法论）**：Scientific Soundness 同等重要；额外承接 **Interest to Readers**——追问"这个方法论结论对读者有何价值"。致命缺陷导向 Major Revision（非一票否决），除非"严重缺陷 + 无原创贡献"才 Reject。
